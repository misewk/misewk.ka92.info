<?php
$PCount = 39;
//    foreach(glob('Players/player*.php') as $file) {
//        include $file;
//    }
for ($i = 0; $i < $PCount; $i++) {
    include("Players/player$i.php");
}

//include("Players/player0.php");
//include("Players/player1.php");
//include("Players/player2.php");
//include("Players/player3.php");
//include("Players/player4.php");
//include("Players/player5.php");
//include("Players/player6.php");
//include("Players/player7.php");
//include("Players/player8.php");
//include("Players/player9.php");
//include("Players/player10.php");
//include("Players/player11.php");
//include("Players/player12.php");
//include("Players/player13.php");
//include("Players/player14.php");
//include("Players/player15.php");
//include("Players/player16.php");
//include("Players/player17.php");
//include("Players/player18.php");
//include("Players/player19.php");
//include("Players/player20.php");
//include("Players/player21.php");
//include("Players/player22.php");
//include("Players/player23.php");
//include("Players/player24.php");
//include("Players/player25.php");
//include("Players/player26.php");
//include("Players/player27.php");
//include("Players/player28.php");
//include("Players/player29.php");
//include("Players/player30.php");
//include("Players/player31.php");
//include("Players/player32.php");
//include("Players/player33.php");
//include("Players/player34.php");
//include("Players/player35.php");
//include("Players/player36.php");
//include("Players/player37.php");
//include("Players/player38.php");
/*
include("Players/player39.php");
include("Players/player40.php");
include("Players/player41.php");
*/
?>