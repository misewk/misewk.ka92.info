<?php
    $Lan["News"] = "News";
    $Lan["Table of result"] = "Table of results";
    $Lan["Prognoz"] = "Forecast";
    $Lan["Rules"] = "Rules";
    $Lan["WC2010"] = "WC2010";
    $Lan["Guestbook"] = "Guestbook";
    $Lan["About"] = "About";
    $Lan["Authorization"] = "Login";
    $Lan["Calendar"] = "Calendar WCRSA";
?>