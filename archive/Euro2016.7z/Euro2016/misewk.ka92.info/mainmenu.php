<?php
    $i = 0;

    $MainMenu[$i]["text"] = $Lan["News"];
    $MainMenu[$i]["link"] = "news";

    $MainMenu[++$i]["text"] = $Lan["Table of result"];
    $MainMenu[$i]["link"] = "table";

    $MainMenu[++$i]["text"] = $Lan["Prognoz"];
    $MainMenu[$i]["link"] = "prognoz";

    $MainMenu[++$i]["text"] = $Lan["Rules"];
    $MainMenu[$i]["link"] = "rules";
    
    /*
    $MainMenu[++$i]["text"] = $Lan["Calendar"];
    $MainMenu[$i]["link"] = "tbwc";
    
    
    $MainMenu[++$i]["text"] = "<b>".$Lan["PrognozTable"]."</b>";
    $MainMenu[$i]["link"] = "tbwc2";
    */
    
    $MainMenu[++$i]["text"] = $Lan["Guestbook"];
    $MainMenu[$i]["link"] = "guest";

    $MainMenu[++$i]["text"] = $Lan["About"];
    $MainMenu[$i]["link"] = "about";

    /*
    $MainMenu[++$i]["text"] = $Lan["Authorization"];
    $MainMenu[$i]["link"] = "login";
    */
?>
