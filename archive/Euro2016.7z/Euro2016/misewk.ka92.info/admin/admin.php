﻿<?php
echo "Hello world";

?>