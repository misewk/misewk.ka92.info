<?php
global $PCount;
//for ($ind = 0; $ind < $PCount; $ind++) include("Players/player".$ind.".php");

// real scores of matches
// tour1
$tour = "tour1";
$Matches[$tour]["start"] = "2016:06:10 22:00:00";

$Matches[$tour][0] = "2-1";
$Matches[$tour][1] = "0-1";
$Matches[$tour][2] = "2-1";
$Matches[$tour][3] = "1-1";

$Matchest[$tour][0] = "2016:06:10 22:00:00";
$Matchest[$tour][1] = "2016:06:11 16:00:00";
$Matchest[$tour][2] = "2016:06:11 19:00:00";
$Matchest[$tour][3] = "2016:06:11 22:00:00";

// tour2
$tour = "tour2";
$Matches[$tour]["start"] = "2016:06:12 16:00:00";
$Matches[$tour][0] = "0-1";
$Matches[$tour][1] = "1-0";
$Matches[$tour][2] = "2-0";
$Matches[$tour][3] = "1-0";
$Matches[$tour][4] = "1-1";
$Matches[$tour][5] = "0-2";

$Matchest[$tour][0] = "2016:06:12 16:00:00";
$Matchest[$tour][1] = "2016:06:12 19:00:00";
$Matchest[$tour][2] = "2016:06:12 22:00:00";
$Matchest[$tour][3] = "2016:06:13 16:00:00";
$Matchest[$tour][4] = "2016:06:13 19:00:00";
$Matchest[$tour][5] = "2016:06:13 22:00:00";

// tour3
$tour = "tour3";
$Matches[$tour]["start"] = "2016:06:14 19:00:00";
$Matches[$tour][0] = "0-2";
$Matches[$tour][1] = "1-1";
$Matches[$tour][2] = "1-2";
$Matches[$tour][3] = "1-1";
$Matches[$tour][4] = "2-0";

$Matchest[$tour][0] = "2016:06:14 19:00:00";
$Matchest[$tour][1] = "2016:06:14 22:00:00";
$Matchest[$tour][2] = "2016:06:15 16:00:00";
$Matchest[$tour][3] = "2016:06:15 19:00:00";
$Matchest[$tour][4] = "2016:06:15 22:00:00";

// tour4
$tour = "tour4";
$Matches[$tour]["start"] = "2016:06:16 16:00:00";
$Matches[$tour][0] = "2-1";
$Matches[$tour][1] = "0-2";
$Matches[$tour][2] = "0-0";
$Matches[$tour][3] = "1-0";
$Matches[$tour][4] = "2-2";
$Matches[$tour][5] = "3-0";

$Matchest[$tour][0] = "2016:06:16 16:00:00";
$Matchest[$tour][1] = "2016:06:16 19:00:00";
$Matchest[$tour][2] = "2016:06:16 22:00:00";
$Matchest[$tour][3] = "2016:06:17 16:00:00";
$Matchest[$tour][4] = "2016:06:17 19:00:00";
$Matchest[$tour][5] = "2016:06:17 22:00:00";

// tour5
$tour = "tour5";
$Matches[$tour]["start"] = "2016:06:18 16:00:00";
$Matches[$tour][0] = "3-0";
$Matches[$tour][1] = "1-1";
$Matches[$tour][2] = "0-0";
$Matches[$tour][3] = "0-1";
$Matches[$tour][4] = "0-0";

$Matchest[$tour][0] = "2016:06:18 16:00:00";
$Matchest[$tour][1] = "2016:06:18 19:00:00";
$Matchest[$tour][2] = "2016:06:18 22:00:00";
$Matchest[$tour][3] = "2016:06:19 22:00:00";
$Matchest[$tour][4] = "2016:06:19 22:00:00";

// tour6
$tour = "tour6";
$Matches[$tour]["start"] = "2016:06:20 16:00:00";
$Matches[$tour][0] = "0-0";
$Matches[$tour][1] = "0-3";
$Matches[$tour][2] = "0-1";
$Matches[$tour][3] = "0-1";
$Matches[$tour][4] = "2-1";
$Matches[$tour][5] = "0-2";

$Matchest[$tour][0] = "2016:06:20 22:00:00";
$Matchest[$tour][1] = "2016:06:20 22:00:00";
$Matchest[$tour][2] = "2016:06:21 19:00:00";
$Matchest[$tour][3] = "2016:06:21 19:00:00";
$Matchest[$tour][4] = "2016:06:21 22:00:00";
$Matchest[$tour][5] = "2016:06:21 22:00:00";

// tour7
$tour = "tour7";
$Matches[$tour]["start"] = "2016:06:22 19:00:00";
$Matches[$tour][0] = "2-1";
$Matches[$tour][1] = "3-3";
$Matches[$tour][2] = "0-1";
$Matches[$tour][3] = "0-1";

$Matchest[$tour][0] = "2016:06:22 19:00:00";
$Matchest[$tour][1] = "2016:06:22 19:00:00";
$Matchest[$tour][2] = "2016:06:22 22:00:00";
$Matchest[$tour][3] = "2016:06:22 22:00:00";

// tour8
$tour = "tour8";
$Matches[$tour]["start"] = "2016:06:25 19:00:00";
$Matches[$tour][0] = "1-1";
$Matches[$tour][1] = "1-0";
$Matches[$tour][2] = "0-0";
$Matches[$tour][3] = "2-1";
$Matches[$tour][4] = "3-0";
$Matches[$tour][5] = "0-4";
$Matches[$tour][6] = "2-0";
$Matches[$tour][7] = "1-2";

$Matchest[$tour][0] = "2016:06:25 16:00:00";
$Matchest[$tour][1] = "2016:06:25 19:00:00";
$Matchest[$tour][2] = "2016:06:25 22:00:00";
$Matchest[$tour][3] = "2016:06:26 16:00:00";
$Matchest[$tour][4] = "2016:06:26 19:00:00";
$Matchest[$tour][5] = "2016:06:26 22:00:00";
$Matchest[$tour][6] = "2016:06:27 19:00:00";
$Matchest[$tour][7] = "2016:06:27 22:00:00";

// tour9
$tour = "tour9";
$Matches[$tour]["start"] = "2016:06:26 19:00:00";
$Matches[$tour][0] = "1-1";
$Matches[$tour][1] = "3-1";
$Matches[$tour][2] = "1-1";
$Matches[$tour][3] = "5-2";
$Matches[$tour][4] = "2-0";
$Matches[$tour][5] = "0-2";
$Matches[$tour][6] = "0-0";

$Matchest[$tour][0] = "2016:06:30 22:00:00";
$Matchest[$tour][1] = "2016:07:01 22:00:00";
$Matchest[$tour][2] = "2016:07:02 22:00:00";
$Matchest[$tour][3] = "2016:07:03 22:00:00";
$Matchest[$tour][4] = "2016:07:06 22:00:00";
$Matchest[$tour][5] = "2016:07:07 22:00:00";
$Matchest[$tour][6] = "2016:07:10 22:00:00";

/*
// tour10
$tour = "tour10";
$Matches[$tour]["start"] = "2014:06:28 19:00:00";
$Matches[$tour][0] = "?-?";
$Matches[$tour][1] = "?-?";
$Matches[$tour][2] = "?-?";
$Matches[$tour][3] = "?-?";

// tour11
$tour = "tour11";
$Matches[$tour]["start"] = "20N46�12.920' E32�08.171'14:07:04 19:00:00";
$Matches[$tour][0] = "?-?";
$Matches[$tour][1] = "?-?";
$Matches[$tour][2] = "?-?";
$Matches[$tour][3] = "?-?";

/*
// tour2
$tour = "tour10";
$Matches[$tour]["start"] = "2010:11:24 19:30:00";
$Matches[$tour][0] = "1-0";
$Matches[$tour][1] = "3-0";

$Matches[$tour][2] = "3-0";
$Matches[$tour][3] = "3-0";

$Matches[$tour][4] = "0-1";
$Matches[$tour][5] = "6-1";

$Matches[$tour][6] = "1-0";
$Matches[$tour][7] = "0-3";

$Matches[$tour][8] = "1-4";
$Matches[$tour][9] = "2-1";

$Matches[$tour][10] = "3-0";

// tour1
$tour = "tour11";
$Matches[$tour]["start"] = "2010:12:07 21:45:00";
$Matches[$tour][0] = "3-3";
$Matches[$tour][1] = "3-0";

$Matches[$tour][2] = "2-2";
$Matches[$tour][3] = "1-2";

$Matches[$tour][4] = "1-1";
$Matches[$tour][5] = "1-1";

$Matches[$tour][6] = "2-0";
$Matches[$tour][7] = "3-1";

// tour2
$tour = "tour12";
$Matches[$tour]["start"] = "2010:12:08 21:45:00";
$Matches[$tour][0] = "3-0";
$Matches[$tour][1] = "1-1";

$Matches[$tour][2] = "1-0";
$Matches[$tour][3] = "1-2";

$Matches[$tour][4] = "4-0";
$Matches[$tour][5] = "0-2";

$Matches[$tour][6] = "3-1";
$Matches[$tour][7] = "2-0";

$Matches[$tour][8] = "0-0";
$Matches[$tour][9] = "0-0";

$Matches[$tour][10] = "1-1";
*/

function GetTourCount()
{
    return 9;
}

function GetWinScores($iPlayerNum)
{
   global $Count;
   $Count = 0;

   $tour = GetTourCount();

   for ($ind = 0; $ind < $tour; $ind++)
   {
       $Count += GetPlayerWinScores($iPlayerNum, $ind + 1);
   }

   return ($Count);
}

////////////////////////////////////////*
function GetWinRest($iPlayerNum)
{
   global $Count;
   $Count = 0;

   $tour = GetTourCount();

   for ($ind = 0; $ind < $tour; $ind++)
    {
       $Count += GetPlayerWinRest($iPlayerNum, $ind + 1);
    }

   return ($Count);
}

////////////////////////////////////////*
function GetNoWinRest($iPlayerNum)
{
   global $Count;
   $Count = 0;

   $tour = GetTourCount();

   for ($ind = 0; $ind < $tour; $ind++)
    {
       $Count += GetPlayerNoWinRest($iPlayerNum, $ind + 1);
    }

   return ($Count);
}

////////////////////////////////////////////////////
function GetPlayerPoint($iPlayerNum)
{
   global $Players;
   $Points = 0;

   $tour = GetTourCount();

   for ($ind = 0; $ind < $tour; $ind++)
    {
       $Points += GetPlayerTourPoints($iPlayerNum, $ind + 1);
    }

   return ($Points);
}

///////////////////////////////////////////////////
function GetPlayerTourPoints($iPlayerNum, $iTourNum)
{
   global $Players, $Matches;
   $Points = 0;
   $iMCount = GetMatchInTour($iTourNum);

   for ($ind = 0; $ind < $iMCount; $ind++)
    {
       $s1 = substr($Matches["tour".$iTourNum][$ind], 0, 1);
       $s2 = substr($Matches["tour".$iTourNum][$ind], 2, 1);

       $p1 = substr($Players[$iPlayerNum]["tour".$iTourNum][$ind], 0, 1);
       $p2 = substr($Players[$iPlayerNum]["tour".$iTourNum][$ind], 2, 1);

       if ((($s1 != "?")&&($s2 != "?"))&&(($p1 != "?")&&($p2 != "?")))
        {

           if ((($s1 > $s2) && ($p1 < $p2)) || (($s1 < $s2) && ($p1 > $p2)))
           {
               $Points -= 1;
           }
           else
           {
               if (($s1 == $p1)&&($s2 == $p2)) $Points += 3;
               else if (($s1 > $s2)&&($p1 > $p2)) $Points += 1;
                    else if (($s1 < $s2)&&($p1 < $p2)) $Points += 1;
                         else if (($s1 == $s2)&&($p1 == $p2)) $Points += 1;
           }
       }
    }

   return $Points;
}

///////////////////////////////////////////////////
function GetPlayerMatchPoints($iPlayerNum, $iTourNum, $iMatchNum)
{
   global $Players, $Matches;
   $Points = 0;

   $s1 = substr($Matches["tour".$iTourNum][$iMatchNum], 0, 1);
   $s2 = substr($Matches["tour".$iTourNum][$iMatchNum], 2, 1);

   $p1 = substr($Players[$iPlayerNum]["tour".$iTourNum][$iMatchNum], 0, 1);
   $p2 = substr($Players[$iPlayerNum]["tour".$iTourNum][$iMatchNum], 2, 1);

   if (($s1 != "?")&&($s2 != "?")&&($p1 != "?")&&($p2 != "?"))
    {
        if ((($s1 > $s2) && ($p1 < $p2)) || (($s1 < $s2) && ($p1 > $p2)))
        {
            $Points -= 1;
        }
        else
        {
            if (($s1 == $p1)&&($s2 == $p2)) $Points += 3;
            else if (($s1 > $s2)&&($p1 > $p2)) $Points += 1;
                 else if (($s1 < $s2)&&($p1 < $p2)) $Points += 1;
                      else if (($s1 == $s2)&&($p1 == $p2)) $Points += 1;
        }


       /*
       if (($s1 == $p1)&&($s2 == $p2)) $Points += 3;
       else if (($s1 > $s2)&&($p1 > $p2)) $Points += 1;
            else if (($s1 < $s2)&&($p1 < $p2)) $Points += 1;
                 else if (($s1 == $s2)&&($p1 == $p2)) $Points += 1;
              */
    }

   return $Points;
}

///////////////////////////////////////////////////
function GetPlayerWinScores($iPlayerNum, $iTourNum)
{
   global $Players, $Matches;
   $Count = 0;
   $iMCount = GetMatchInTour($iTourNum);

   for ($ind = 0; $ind < $iMCount; $ind++)
    {
       $s1 = substr($Matches["tour".$iTourNum][$ind], 0, 1);
       $s2 = substr($Matches["tour".$iTourNum][$ind], 2, 1);

       $p1 = substr($Players[$iPlayerNum]["tour".$iTourNum][$ind], 0, 1);
       $p2 = substr($Players[$iPlayerNum]["tour".$iTourNum][$ind], 2, 1);
        
        //echo "s1=".$s1."s2=".$s2."p1=".$p1."p2=".$p2."<br>";
       if (($s1 != "?")&&($s2 != "?")&&($p1 != "?")&&($p2 != "?"))
          {
           if (($s1 == $p1)&&($s2 == $p2)) $Count += 1;
       }
    }

   return $Count;
}

///////////////////////////////////////////////////
function GetPlayerWinRest($iPlayerNum, $iTourNum)
{
   global $Players, $Matches;
   $Count = 0;
   $iMCount = GetMatchInTour($iTourNum);

   for ($ind = 0; $ind < $iMCount; $ind++)
    {
       $s1 = substr($Matches["tour".$iTourNum][$ind], 0, 1);
       $s2 = substr($Matches["tour".$iTourNum][$ind], 2, 1);

       $p1 = substr($Players[$iPlayerNum]["tour".$iTourNum][$ind], 0, 1);
       $p2 = substr($Players[$iPlayerNum]["tour".$iTourNum][$ind], 2, 1);

       if (($s1 != "?")&&($s2 != "?")&&($p1 != "?")&&($p2 != "?"))
        {
           if (($s1 == $p1)&&($s2 == $p2)) continue;

           if (($s1 > $s2)&&($p1 > $p2))
            {
               $Count += 1;
               continue;
            }


          if (($s1 < $s2)&&($p1 < $p2))
            {
               $Count += 1;
               continue;
            }

          if (($s1 == $s2)&&($p1 == $p2))
            {
               $Count += 1;
               continue;
            }
       }
    }

//if (!$iPlayerNum) echo $Count."<br>" ;
return $Count;
}

///////////////////////////////////////////////////
function GetPlayerNoWinRest($iPlayerNum, $iTourNum)
{
global $Players, $Matches;
$Count = 0;
$iMCount = GetMatchInTour($iTourNum);

for ($ind = 0; $ind < $iMCount; $ind++)
    {
    $s1 = substr($Matches["tour".$iTourNum][$ind], 0, 1);
    $s2 = substr($Matches["tour".$iTourNum][$ind], 2, 1);

    $p1 = substr($Players[$iPlayerNum]["tour".$iTourNum][$ind], 0, 1);
    $p2 = substr($Players[$iPlayerNum]["tour".$iTourNum][$ind], 2, 1);

    if (($s1 != "?")&&($s2 != "?")&&($p1 != "?")&&($p2 != "?"))
        {

            if ((($s1 > $s2)&&($p1 < $p2)) || (($s1 < $s2)&&($p1 > $p2)))
            {
                $Count += 1;
            }
        }
    }

//if (!$iPlayerNum) echo $Count."<br>" ;
return $Count;
}


////////////////////////////////////////////////////
function GetMatchInTour($iTourNum)
{

   //if ($iTourNum == 4) return 7;
    //$rest = $iTourNum % 2;

   // if ($rest == 0) return 11;
//    else return 8;
//return 8;

    switch ($iTourNum)
    {
        case 1:
            return 4;
        case 2:
            return 6;
        case 3:
            return 5;
        case 4:
            return 6;
        case 5:
            return 5;
        case 6:
            return 6;
        case 7:
            return 4;
        case 8:
            return 8;
        case 9:
            return 7;
    }

    return 0;
}

////////////////////////////////////////////////////
function ShowScore($iPlayerNum, $iTourNum, $iMatchNum)
{
   global $Players, $Matches, $Matchest, $_GET;

   $god = isset($_GET["iddqd"]) ? true : false;

   $Text = "?-?";

   $pp = $Players[$iPlayerNum]["tour".$iTourNum][$iMatchNum];
   if ($pp == "?-?")
       return $pp;
   
   $current = date("Y:m:d H:i:s");
   $tourdate = $Matchest["tour".$iTourNum][$iMatchNum];

   if ($current < $tourdate && !$god)
   {
        $tm = substr($tourdate, 11, 5);
        return $tm;
   }

   $iRes = GetPlayerMatchPoints($iPlayerNum, $iTourNum, $iMatchNum);

   switch ($iRes)
   {
       case -1:
       {
           $Text = "<div class=\"red b\">".$Players[$iPlayerNum]["tour".$iTourNum][$iMatchNum]."</div>";
           break;
       }

       case 0:
       {
           $Text = "<div class=\"b\">".$Players[$iPlayerNum]["tour".$iTourNum][$iMatchNum]."</div>";
           break;
       }

       case 1:
       {
           $Text = "<div class=\"wright_result b\">".$Players[$iPlayerNum]["tour".$iTourNum][$iMatchNum]."</div>";
            break;
       }

       case 3:
       {
           $Text = "<div class=\"wright_score b\">".$Players[$iPlayerNum]["tour".$iTourNum][$iMatchNum]."</div>";
           break;
       }
   }

    return $Text;
}
////////////////////////////////////////////////////
function ShowPlayer($iPlayerNum)
{
   global $Players, $Matches;

   //$Text = "<a target=new href=shplayer.php?iPNum=$iPlayerNum><b>&nbsp;<u><font size = 4>".$Players[$iPlayerNum]["name"]."</font></u></b></a>";
   $Text = "&nbsp;".$Players[$iPlayerNum]["name"];
   return $Text;
}
?>
