<?php
    $Title = "��������� ����� 2010";
    
    $obj->assign("BodyMenu", "");
    $obj->assign("BodyCaption", $Title);
    
    // sub hat
    $Text = "<table border=0 align=center cellspacing=\"0\" cellpadding=\"0\">
    <tr><td align=\"center\" valign=\"middle\"><img src=\"../i/group.gif\" border=\"1\"></td></tr></table>";

    $obj->assign("Body", $Text);
