<?php
    $i = 0;

    $TourMenu[$i]["text"] = "���� 1-4 (1)";
    $TourMenu[$i]["link"] = "prognoz&sp=1";

    $TourMenu[++$i]["text"] = "���� 5-11 (2)";
    $TourMenu[$i]["link"] = "prognoz&sp=2";

    $TourMenu[++$i]["text"] = "���� 12-17 (3)";
    $TourMenu[$i]["link"] = "prognoz&sp=3";

    $TourMenu[++$i]["text"] = "���� 18-21 (4)";
    $TourMenu[$i]["link"] = "prognoz&sp=4";

    $TourMenu[++$i]["text"] = "���� 22-26 (5)";
    $TourMenu[$i]["link"] = "prognoz&sp=5";
    
    $TourMenu[++$i]["text"] = "���� 27-32 (6)";
    $TourMenu[$i]["link"] = "prognoz&sp=6";

    $TourMenu[++$i]["text"] = "���� 33-36 (7)";
    $TourMenu[$i]["link"] = "prognoz&sp=7";

    $TourMenu[++$i]["text"] = "Round of 16 (8)";
    $TourMenu[$i]["link"] = "prognoz&sp=8";

    $TourMenu[++$i]["text"] = "Quater/semi-finals, final (9)";
    $TourMenu[$i]["link"] = "prognoz&sp=9";
/*
    $TourMenu[++$i]["text"] = "���� 49-56 (10)";
    $TourMenu[$i]["link"] = "prognoz&sp=10";

    $TourMenu[++$i]["text"] = "���� 57-64 (11)";
    $TourMenu[$i]["link"] = "prognoz&sp=11";
*/
?>