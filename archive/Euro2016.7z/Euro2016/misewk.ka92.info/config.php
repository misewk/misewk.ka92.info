<?php
	
	// Database connect settings
	/*
	$Config["DB"] = "ka921_ka92";
	$Config["LOGIN"] = "ka921_ka92";
	$Config["PASSWORD"] = "ghtptynfwbz";
	$Config["HOST"] = "db2.freehost.com.ua";
	*/
	$PCount = 1;
	
	$Config["DB"] = "total";
	$Config["LOGIN"] = "root";
	$Config["PASSWORD"] = "";
	$Config["HOST"] = "localhost";
	
	// Guestbook settings
	$Config["GUEST_MESSAGE_ON_PAGE"] = 10;

	//
?>