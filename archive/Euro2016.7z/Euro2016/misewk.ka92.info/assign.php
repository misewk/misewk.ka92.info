<?php

$Assign = array(
                //
                "news" =>  "news/news.php",

                //
                "table" =>  "table/maintable.php",

                //
                "prognoz" => "forecast/tourpage.php",

                //
                "tbwc" => "calwc.php",
                // ��������� �������
                "tbwc2" => "tbwc/main.php",
                //
                "rules" => "rules/rulespage.php",

                // ��������
                "guest" => "guestbook/index.php",

                //
                "about" => "about/aboutpage.php",

                //
                "no" => "404/no.php"
            );
?>