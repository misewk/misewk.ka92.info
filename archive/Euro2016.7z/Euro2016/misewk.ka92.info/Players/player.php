<?php
// Players on totalizator
$num = 1;
$Players[$num]["name"] = "������� ������";    
$Players[$num]["rel"]  = "������";

$tour = "tour1";
$ind = 0;

$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";

$tour = "tour2";
$ind = 0;

$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";

$tour = "tour3";
$ind = 0;
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";
$Players[$num][$tour][]  = "?-?";



