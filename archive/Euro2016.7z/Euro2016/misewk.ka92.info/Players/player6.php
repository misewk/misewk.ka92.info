<?php
// Players on totalizator
$num = 6;
$Players[$num]["name"] = "������� ������";
$Players[$num]["rel"]  = "��������";

$tour = "tour1";
$ind = 0;

$Players[$num][$tour][$ind++]  = "2-0";
$Players[$num][$tour][$ind++]  = "0-2";
$Players[$num][$tour][$ind++]  = "0-1";
$Players[$num][$tour][$ind++]  = "2-1";

$tour = "tour2";
$ind = 0;

$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "2-1";
$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "2-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "1-2";

$tour = "tour3";
$ind = 0;

$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "2-0";
$Players[$num][$tour][$ind++]  = "1-2";
$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "3-0";

$tour = "tour4";
$ind = 0;

$Players[$num][$tour][$ind++]  = "2-0";
$Players[$num][$tour][$ind++]  = "2-1";
$Players[$num][$tour][$ind++]  = "2-0";
$Players[$num][$tour][$ind++]  = "2-0";
$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "3-1";

$tour = "tour5";
$ind = 0;

$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "2-1";
$Players[$num][$tour][$ind++]  = "2-0";
$Players[$num][$tour][$ind++]  = "1-1";

$tour = "tour6";
$ind = 0;

$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "2-1";
$Players[$num][$tour][$ind++]  = "0-2";
$Players[$num][$tour][$ind++]  = "0-2";
$Players[$num][$tour][$ind++]  = "1-1";

$tour = "tour7";
$ind = 0;

$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "1-2";
$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "2-0";

$tour = "tour8";
$ind = 0;

$Players[$num][$tour][$ind++]  = "0-2";
$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "2-0";
$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "2-0";
$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "1-1";

$tour = "tour9";
$ind = 0;

$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "?-?";
$Players[$num][$tour][$ind++]  = "?-?";
$Players[$num][$tour][$ind++]  = "?-?";
/*
$tour = "tour10";
$ind = 0;

$Players[$num][$tour][$ind++]  = "2-1";
$Players[$num][$tour][$ind++]  = "2-0";
$Players[$num][$tour][$ind++]  = "3-0";
$Players[$num][$tour][$ind++]  = "0-1";
$Players[$num][$tour][$ind++]  = "2-1";
$Players[$num][$tour][$ind++]  = "4-0";
$Players[$num][$tour][$ind++]  = "2-0";
$Players[$num][$tour][$ind++]  = "0-1";

$tour = "tour11";
$ind = 0;

$Players[$num][$tour][$ind++]  = "2-2";
$Players[$num][$tour][$ind++]  = "1-2";
$Players[$num][$tour][$ind++]  = "1-1";
$Players[$num][$tour][$ind++]  = "2-0";
$Players[$num][$tour][$ind++]  = "0-1";
$Players[$num][$tour][$ind++]  = "4-1";
$Players[$num][$tour][$ind++]  = "2-2";
$Players[$num][$tour][$ind++]  = "3-0";

$tour = "tour12";
$ind = 0;

$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
$Players[$num][$tour][$ind++]  = "0-0";
*/
?>
